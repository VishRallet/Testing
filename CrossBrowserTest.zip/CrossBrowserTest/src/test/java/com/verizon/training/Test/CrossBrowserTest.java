package com.verizon.training.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
public class CrossBrowserTest {
    WebDriver driver;
    @Parameters("browser")
    @BeforeMethod
    public void setup(String browser) {
        driver = BrowserFactory.getDriver(browser);
        driver.get("file:///C:/Users/verizon/Documents/workspace-spring-tools-for-eclipse-4.31.0.RELEASE/CrossBrowserTest/index.html");
    }
    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
    @Test
    public void testLoginPageTitle() {
        String title = driver.getTitle();
        Assert.assertEquals(title, "", "Page title mismatch!");
    }
    @Test
    public void testLoginFunctionality() {
        driver.findElement(By.id("username")).sendKeys("validUser");
        driver.findElement(By.id("password")).sendKeys("validPass");
        driver.findElement(By.id("loginBtn")).click();
        Assert.assertTrue(driver.getCurrentUrl().contains("dashboard"), "Login failed!");
    }
}