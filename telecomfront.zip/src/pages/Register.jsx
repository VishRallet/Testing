import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

export default function Register() {
  const [formData, setFormData] = useState({
    firstname: "",
    lastname: "",
    mobileNumber: "",
    city: "",
    password: "",
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:8080/api/user/register", formData);
      localStorage.setItem("user", JSON.stringify(res.data));
      navigate("/dashboard");
    } catch (err) {
      alert("Registration failed: " + err.response?.data || err.message);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
      <form onSubmit={handleRegister} className="bg-white p-6 rounded-xl shadow-md w-80">
        <h2 className="text-2xl font-bold mb-4 text-center">Register</h2>
        <input name="firstname" placeholder="First Name" onChange={handleChange} className="w-full mb-3 p-2 border rounded" required />
        <input name="lastname" placeholder="Last Name" onChange={handleChange} className="w-full mb-3 p-2 border rounded" required />
        <input name="mobileNumber" placeholder="Mobile Number" onChange={handleChange} className="w-full mb-3 p-2 border rounded" required />
        <input name="city" placeholder="City" onChange={handleChange} className="w-full mb-3 p-2 border rounded" required />
        <input name="password" type="password" placeholder="Password" onChange={handleChange} className="w-full mb-3 p-2 border rounded" required />
        <button type="submit" className="w-full bg-purple-600 text-white py-2 rounded hover:bg-purple-700">
          Register
        </button>
      </form>
    </div>
  );
}
