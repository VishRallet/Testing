import { useState } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom"; // Import Link
import "bootstrap/dist/css/bootstrap.min.css";
import "../index.css"; // Import the CSS file for styling

export default function AdminAuth() {
  const [activeTab, setActiveTab] = useState("login");
  const [message, setMessage] = useState({ type: "", text: "" });

  // Login state
  const [loginData, setLoginData] = useState({
    mobileNumber: "",
    password: "",
  });

  // Register state
  const [registerData, setRegisterData] = useState({
    firstname: "",
    lastname: "",
    city: "",
    mobileNumber: "",
    password: "",
    adminKey: "",
  });

  const navigate = useNavigate();

  const clearMessage = () => {
    setTimeout(() => {
      setMessage({ type: "", text: "" });
    }, 5000);
  };

  const handleLoginChange = (e) => {
    setLoginData({ ...loginData, [e.target.name]: e.target.value });
  };

  const handleRegisterChange = (e) => {
    setRegisterData({ ...registerData, [e.target.name]: e.target.value });
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:8080/api/admin/login", loginData);
      // Save admin info in localStorage
      localStorage.setItem("admin", JSON.stringify(res.data));
      setMessage({ type: "success", text: "Login successful!" });
      clearMessage();
      navigate("/admin/dashboard"); // <-- redirect to dashboard
    } catch (err) {
      setMessage({ type: "danger", text: "Login failed: " + (err.response?.data || err.message) });
      clearMessage();
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const { adminKey, ...rest } = registerData;
      const res = await axios.post(
        "http://localhost:8080/api/admin/create",
        rest,
        {
          headers: {
            "X-ADMIN-KEY": adminKey,
          },
        }
      );
      setMessage({ type: "success", text: "Admin created successfully!" });
      setRegisterData({
        firstname: "",
        lastname: "",
        city: "",
        mobileNumber: "",
        password: "",
        adminKey: "",
      });
      setActiveTab("login"); // switch to login after registration
      clearMessage();
    } catch (err) {
      setMessage({ type: "danger", text: "Registration failed: " + (err.response?.data || err.message) });
      clearMessage();
    }
  };

  return (
    <div className="container py-5 admin-page">
      <Link to="/" className="back-btn-admin">
        Back
      </Link>
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card shadow-sm">
            <div className="card-header d-flex justify-content-around">
              <button
                className={`btn ${activeTab === "login" ? "btn-primary" : "btn-outline-primary"}`}
                onClick={() => setActiveTab("login")}
              >
                Login
              </button>
              <button
                className={`btn ${activeTab === "register" ? "btn-primary" : "btn-outline-primary"}`}
                onClick={() => setActiveTab("register")}
              >
                Register
              </button>
            </div>
            <div className="card-body">
              {message.text && (
                <div className={`alert alert-${message.type}`} role="alert">
                  {message.text}
                </div>
              )}

              {activeTab === "login" && (
                <form onSubmit={handleLogin}>
                  <div className="mb-3">
                    <label className="form-label">Mobile Number</label>
                    <input
                      type="text"
                      className="form-control"
                      name="mobileNumber"
                      value={loginData.mobileNumber}
                      onChange={handleLoginChange}
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Password</label>
                    <input
                      type="password"
                      className="form-control"
                      name="password"
                      value={loginData.password}
                      onChange={handleLoginChange}
                      required
                    />
                  </div>
                  <button type="submit" className="btn btn-primary w-100">
                    Login
                  </button>
                </form>
              )}

              {activeTab === "register" && (
                <form onSubmit={handleRegister}>
                  <div className="mb-3">
                    <label className="form-label">First Name</label>
                    <input
                      type="text"
                      className="form-control"
                      name="firstname"
                      value={registerData.firstname}
                      onChange={handleRegisterChange}
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Last Name</label>
                    <input
                      type="text"
                      className="form-control"
                      name="lastname"
                      value={registerData.lastname}
                      onChange={handleRegisterChange}
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">City</label>
                    <input
                      type="text"
                      className="form-control"
                      name="city"
                      value={registerData.city}
                      onChange={handleRegisterChange}
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Mobile Number</label>
                    <input
                      type="text"
                      className="form-control"
                      name="mobileNumber"
                      value={registerData.mobileNumber}
                      onChange={handleRegisterChange}
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Password</label>
                    <input
                      type="password"
                      className="form-control"
                      name="password"
                      value={registerData.password}
                      onChange={handleRegisterChange}
                      required
                    />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Admin Key</label>
                    <input
                      type="password"
                      className="form-control"
                      name="adminKey"
                      value={registerData.adminKey}
                      onChange={handleRegisterChange}
                      required
                    />
                  </div>
                  <button type="submit" className="btn btn-success w-100">
                    Register
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
