package com.telecom.portal.model;

public enum Role {
    USER,
    ADMIN
}
