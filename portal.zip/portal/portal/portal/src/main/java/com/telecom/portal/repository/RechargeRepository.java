package com.telecom.portal.repository;

import com.telecom.portal.model.Recharge;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface RechargeRepository extends JpaRepository<Recharge, Long> {
    List<Recharge> findByUserId(Long userId);
    List<Recharge> findByPlanId(Long planId);
}
