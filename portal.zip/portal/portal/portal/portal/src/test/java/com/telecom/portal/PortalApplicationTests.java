package com.telecom.portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortalApplicationTests {

    @Test
    void contextLoads() {
        // This will fail if the application context cannot start
    }
}
