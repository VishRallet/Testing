package com.verizon.training.CSVDataProvider;
import static org.testng.Assert.assertNotNull;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
public class LoginTest {
    WebDriver driver;
    @BeforeMethod
    public void setup() {
        driver = BrowserFactory.getDriver("chrome");
        driver.get("file:///C:\\Users\\verizon\\Documents\\workspace-spring-tools-for-eclipse-4.31.0.RELEASE\\CSVDataProvider\\index.html");
    }
    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
    @Test(dataProvider = "loginData", dataProviderClass = CSVDataProvider.class)
    public void testLogin(String username, String password, String expectedResult) {
        driver.findElement(By.id("username")).clear();
        driver.findElement(By.id("username")).sendKeys(username);
        driver.findElement(By.id("password")).clear();
        driver.findElement(By.id("password")).sendKeys(password);
//        //driver.findElement(By.id("loginBtn")).click();
//        if (expectedResult.equalsIgnoreCase("success")) {
//            Assert.assertTrue(driver.getCurrentUrl().contains("dashboard"),
//                    "Expected login to succeed but it failed.");
//        } else {
//            String errorMsg = driver.findElement(By.id("errorMessage")).getText();
//            Assert.assertTrue(errorMsg.contains("Invalid") || errorMsg.contains("required"),
//                    "Expected error message for failed login but got none.");
//        }
        assertNotNull(username);
    }
}