package com.verizon.training.CSVDataProvider;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.testng.annotations.DataProvider;
public class CSVDataProvider {
    @DataProvider(name = "loginData")
    public static Iterator<Object[]> readCSV() throws IOException {
        List<Object[]> testData = new ArrayList<>();
        //String filePath = System.getProperty("user.dir") + "C:\\Users\\verizon\\Desktop.data.csv";
        BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\verizon\\Desktop\\data.csv"));
        String line;
        boolean header = true;
        while ((line = reader.readLine()) != null) {
            if (header) { // skip header row
                header = false;
                continue;
            }
            String[] data = line.split(",");
            testData.add(new Object[]{data[0], data[1], data[2]});
        }
        reader.close();
        return testData.iterator();
    }
}